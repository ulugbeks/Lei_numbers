@extends('layouts.app')

@section('title', 'Home')

@section('content')

@include('partials.header')

<!-- SI Breadcumb Area -->
<section class="si__breadcumb__area bg" style="background: url(assets/images/breadcumb/Hero.png);">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<div class="si__breadcumb__text text-center">
					<h1>Blog Details</h1>
					<span><a href="index.html">Home</a> <i class="fa-regular fa-chevron-right"></i> Blog Details</span>
				</div>
			</div>
		</div>
	</div>
</section>

<!-- SI Blog Details left -->
<div class="si__blog__details__area">
	<div class="container">
		<div class="row">
			<div class="col-lg-8">
				<div class="si__blog__details__thumb wow fadeInUp animated" data-wow-delay=".75s">
					<img src="assets/images/blog-details/pic-1.png" alt="">
					<span>
						<svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
						<path d="M3.85052 2.80038C3.64282 2.80038 3.43979 2.86197 3.26709 2.97736C3.0944 3.09275 2.9598 3.25676 2.88032 3.44865C2.80083 3.64053 2.78004 3.85168 2.82056 4.05539C2.86108 4.25909 2.96109 4.44621 3.10796 4.59308C3.25482 4.73994 3.44194 4.83996 3.64564 4.88048C3.84935 4.921 4.0605 4.9002 4.25239 4.82072C4.44427 4.74123 4.60828 4.60664 4.72367 4.43394C4.83907 4.26125 4.90065 4.05821 4.90065 3.85052C4.90065 3.572 4.79002 3.3049 4.59308 3.10796C4.39614 2.91102 4.12903 2.80038 3.85052 2.80038ZM13.3858 6.09781L7.49799 0.203038C7.43258 0.138153 7.355 0.0868184 7.2697 0.0519786C7.1844 0.0171389 7.09307 -0.000520993 7.00093 1.17015e-05H0.700103C0.514428 1.17015e-05 0.336356 0.0737711 0.205064 0.205064C0.0737711 0.336356 1.17015e-05 0.514428 1.17015e-05 0.700103V7.00093C-0.000520993 7.09307 0.0171389 7.1844 0.0519786 7.2697C0.0868184 7.355 0.138153 7.43258 0.203038 7.49799L6.09781 13.3858C6.49161 13.7791 7.02543 14 7.58201 14C8.13858 14 8.6724 13.7791 9.0662 13.3858L13.3858 9.1012C13.7791 8.7074 14 8.17359 14 7.61701C14 7.06044 13.7791 6.52662 13.3858 6.13282V6.09781ZM12.3986 8.07207L8.07207 12.3916C7.9409 12.522 7.76346 12.5952 7.57851 12.5952C7.39355 12.5952 7.21611 12.522 7.08494 12.3916L1.4002 6.71389V1.4002H6.71389L12.3986 7.08494C12.4635 7.15036 12.5149 7.22794 12.5497 7.31324C12.5845 7.39853 12.6022 7.48987 12.6017 7.58201C12.6009 7.76567 12.528 7.94167 12.3986 8.07207Z" fill="#DF2E2E"/>
						</svg>
						 Web desing</span>
					<span>
						<svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
						<path d="M11.8998 4.19994H11.1998V2.09997C11.1998 1.54302 10.9786 1.00889 10.5848 0.615067C10.191 0.221246 9.65682 0 9.09987 0H2.09997C1.54302 0 1.00889 0.221246 0.615067 0.615067C0.221246 1.00889 0 1.54302 0 2.09997V10.4999C0.000689827 10.638 0.0422709 10.7729 0.119503 10.8876C0.196735 11.0022 0.306162 11.0913 0.433994 11.1438C0.517068 11.183 0.608168 11.2022 0.69999 11.1998C0.792114 11.2004 0.883436 11.1827 0.968721 11.1479C1.05401 11.113 1.13158 11.0617 1.19698 10.9968L3.16396 9.02287H4.19994V10.0309C4.19994 10.5878 4.42119 11.1219 4.81501 11.5158C5.20883 11.9096 5.74297 12.1308 6.29991 12.1308H11.1438L12.8028 13.7968C12.8682 13.8617 12.9458 13.913 13.0311 13.9478C13.1164 13.9827 13.2077 14.0003 13.2998 13.9998C13.3916 14.0022 13.4827 13.983 13.5658 13.9438C13.6936 13.8913 13.8031 13.8021 13.8803 13.6875C13.9575 13.5729 13.9991 13.438 13.9998 13.2998V6.29991C13.9998 5.74297 13.7786 5.20883 13.3847 4.81501C12.9909 4.42119 12.4568 4.19994 11.8998 4.19994ZM4.19994 6.29991V7.62289H2.87696C2.78484 7.62236 2.69351 7.64002 2.60823 7.67485C2.52294 7.70969 2.44537 7.76101 2.37997 7.82589L1.39998 8.81288V2.09997C1.39998 1.91432 1.47373 1.73628 1.605 1.605C1.73628 1.47373 1.91432 1.39998 2.09997 1.39998H9.09987C9.28552 1.39998 9.46357 1.47373 9.59484 1.605C9.72611 1.73628 9.79986 1.91432 9.79986 2.09997V4.19994H6.29991C5.74297 4.19994 5.20883 4.42119 4.81501 4.81501C4.42119 5.20883 4.19994 5.74297 4.19994 6.29991ZM12.5998 11.6128L11.8998 10.9128C11.835 10.8467 11.7577 10.7941 11.6724 10.758C11.5871 10.722 11.4955 10.7032 11.4028 10.7029H6.29991C6.11426 10.7029 5.93622 10.6291 5.80494 10.4978C5.67367 10.3666 5.59992 10.1885 5.59992 10.0029V6.29991C5.59992 6.11426 5.67367 5.93622 5.80494 5.80494C5.93622 5.67367 6.11426 5.59992 6.29991 5.59992H11.8998C12.0855 5.59992 12.2635 5.67367 12.3948 5.80494C12.5261 5.93622 12.5998 6.11426 12.5998 6.29991V11.6128Z" fill="#DF2E2E"/>
						</svg>
						Comments (05)
					</span>
						<h3>Leading businesses, shaping the future</h3>
						<p>Web designing in a powerful way of just not an only professions, however, in a passion for our<br> Company. We have to a tendency to believe the idea that smart looking </p>
						<h6>Business excellence, unmatched service</h6>
						<p>Web designing in a powerful way of just not an only professions, however, in a passion for our the<br> Company. We have to a tendency to believe the idea that smart looking of any websitet in on and visitors.Web designing in a powerful way of just not an only profession </p>
				</div>
				<div class="si__blog__details__main wow fadeInUp animated" data-wow-delay=".75s">
					<div class="si__blog__details__list">
						<ul>
							<li><i class="fa-solid fa-check"></i> Financial Strategy Accelerators</li>
							<li><i class="fa-solid fa-check"></i> Secure Your Business's Financial Future </li>
							<li><i class="fa-solid fa-check"></i> Empower Your Business with Smart</li>
						</ul>
					</div>
					<div class="si__blog__details__list">
						<ul>
							<li><i class="fa-solid fa-check"></i> Gain a Competitive Edge with Strategic</li>
							<li><i class="fa-solid fa-check"></i> Drive Financial Success with Professional </li>
							<li><i class="fa-solid fa-check"></i> Navigate the Financial Landscape</li>
						</ul>
					</div>
				</div>
				<div class="si__blog__details__social wow fadeInUp animated" data-wow-delay=".75s">
					<div class="si__blog__details__textthree">
						<h6>Tags:</h6>
						<span><a href="#">Loan</a></span>
						<span><a href="#">Budgeting</a></span>
						<span><a href="#">Forecasting</a></span>
					</div>
					<div class="si__blog__details__icon">
						<span>Share:</span>
						<a href="#"><i class="fa-brands fa-instagram"></i></a>
						<a href="#"><i class="fa-brands fa-facebook-f"></i></a>
						<a href="#"><i class="fa-brands fa-pinterest-p"></i></a>
						<a href="#"><i class="fa-brands fa-linkedin-in"></i></a>
					</div>
				</div>
				<div class="si__blog__details__btn wow fadeInUp animated" data-wow-delay=".75s">
					<a href="#"><i class="fa-regular fa-chevron-left"></i><span>Previous</span></a>					
					<a href="#"><span>Next</span><i class="fa-regular fa-chevron-right"></i></a>
				</div>
				<div class="si__blog__details__comment__section wow fadeInUp animated" data-wow-delay=".75s">
					<h2>Add a comment</h2>
					<p>By using form u agree with the message sorage, you can contact us directly now</p>
				</div>
				<!-- Comment Form -->
				<form action="https://formspree.io/f/maygbqwa" method="post">
					<div class="si__blog__details__from">
						<input name="text" type="text" placeholder="Your Name">
						<input name="email" type="email" placeholder="Your Email">
						<input name="text" type="text" placeholder="Your Website">
					</div>
					<div class="si__blog__details__messenge">
						<textarea  placeholder="Write your messege"></textarea>
						<div class="float-left">
							<input type="checkbox" id="terms" required>
							 <label for="terms">Save My Name Email And Website</label>
						</div>
					</div>
					<div class="si__blog__details__btn__four">
						<button type="submit" class="si__btn__four mt-15"> post comment </button>
					</div>
				</form>
				<!-- Comment Form -->
			</div>
			<div class="col-lg-4">
				<div class="si__blog__details__sidebar">
					<div class="si__blog__details__widget wow fadeInUp animated" data-wow-delay=".75s">
						<h6>Search Here</h6>
						<input type="text" placeholder="Search..">
						<div class="si__blog__details__search">
							<a href="#"><i class="fa-sharp fa-regular fa-magnifying-glass"></i></a>
						</div>
					</div>
					<div class="si__blog__details__widget wow fadeInUp animated" data-wow-delay=".3s">
						<h6>Popular Post</h6>
						<div class="si__blog__details__boxthree">
							<div class="si__blog__details__img">
								<img src="assets/images/blog-details/11.png" alt="">
							</div>
							<div class="si__blog__details__date">
								<span><svg width="11" height="13" viewBox="0 0 11 13" fill="none" xmlns="http://www.w3.org/2000/svg">
									<path d="M3.5625 2H6.9375V1.0625C6.9375 0.757812 7.17188 0.5 7.5 0.5C7.80469 0.5 8.0625 0.757812 8.0625 1.0625V2H9C9.82031 2 10.5 2.67969 10.5 3.5V11C10.5 11.8438 9.82031 12.5 9 12.5H1.5C0.65625 12.5 0 11.8438 0 11V3.5C0 2.67969 0.65625 2 1.5 2H2.4375V1.0625C2.4375 0.757812 2.67188 0.5 3 0.5C3.30469 0.5 3.5625 0.757812 3.5625 1.0625V2ZM1.125 6.3125H3V5H1.125V6.3125ZM1.125 7.4375V8.9375H3V7.4375H1.125ZM4.125 7.4375V8.9375H6.375V7.4375H4.125ZM7.5 7.4375V8.9375H9.375V7.4375H7.5ZM9.375 5H7.5V6.3125H9.375V5ZM9.375 10.0625H7.5V11.375H9C9.1875 11.375 9.375 11.2109 9.375 11V10.0625ZM6.375 10.0625H4.125V11.375H6.375V10.0625ZM3 10.0625H1.125V11C1.125 11.2109 1.28906 11.375 1.5 11.375H3V10.0625ZM6.375 5H4.125V6.3125H6.375V5Z" fill="#DF2E2E"/>
									</svg>
										15 January, 2025
								</span>
								<a href="#">Financial Performance the a <br> tge Boosters</a>
							</div>
						</div>
						<div class="si__blog__details__boxthree">
							<div class="si__blog__details__img">
								<img src="assets/images/blog-details/22.png" alt="">
							</div>
							<div class="si__blog__details__date">
								<span><svg width="11" height="13" viewBox="0 0 11 13" fill="none" xmlns="http://www.w3.org/2000/svg">
									<path d="M3.5625 2H6.9375V1.0625C6.9375 0.757812 7.17188 0.5 7.5 0.5C7.80469 0.5 8.0625 0.757812 8.0625 1.0625V2H9C9.82031 2 10.5 2.67969 10.5 3.5V11C10.5 11.8438 9.82031 12.5 9 12.5H1.5C0.65625 12.5 0 11.8438 0 11V3.5C0 2.67969 0.65625 2 1.5 2H2.4375V1.0625C2.4375 0.757812 2.67188 0.5 3 0.5C3.30469 0.5 3.5625 0.757812 3.5625 1.0625V2ZM1.125 6.3125H3V5H1.125V6.3125ZM1.125 7.4375V8.9375H3V7.4375H1.125ZM4.125 7.4375V8.9375H6.375V7.4375H4.125ZM7.5 7.4375V8.9375H9.375V7.4375H7.5ZM9.375 5H7.5V6.3125H9.375V5ZM9.375 10.0625H7.5V11.375H9C9.1875 11.375 9.375 11.2109 9.375 11V10.0625ZM6.375 10.0625H4.125V11.375H6.375V10.0625ZM3 10.0625H1.125V11C1.125 11.2109 1.28906 11.375 1.5 11.375H3V10.0625ZM6.375 5H4.125V6.3125H6.375V5Z" fill="#DF2E2E"/>
									</svg>
										15 January, 2025
								</span>
								<a href="#">Secure Your Business's the <br>  Financial Future Today</a>
							</div>
						</div>
						<div class="si__blog__details__boxthree">
							<div class="si__blog__details__img">
								<img src="assets/images/blog-details/33.png" alt="">
							</div>
							<div class="si__blog__details__date">
								<span><svg width="11" height="13" viewBox="0 0 11 13" fill="none" xmlns="http://www.w3.org/2000/svg">
									<path d="M3.5625 2H6.9375V1.0625C6.9375 0.757812 7.17188 0.5 7.5 0.5C7.80469 0.5 8.0625 0.757812 8.0625 1.0625V2H9C9.82031 2 10.5 2.67969 10.5 3.5V11C10.5 11.8438 9.82031 12.5 9 12.5H1.5C0.65625 12.5 0 11.8438 0 11V3.5C0 2.67969 0.65625 2 1.5 2H2.4375V1.0625C2.4375 0.757812 2.67188 0.5 3 0.5C3.30469 0.5 3.5625 0.757812 3.5625 1.0625V2ZM1.125 6.3125H3V5H1.125V6.3125ZM1.125 7.4375V8.9375H3V7.4375H1.125ZM4.125 7.4375V8.9375H6.375V7.4375H4.125ZM7.5 7.4375V8.9375H9.375V7.4375H7.5ZM9.375 5H7.5V6.3125H9.375V5ZM9.375 10.0625H7.5V11.375H9C9.1875 11.375 9.375 11.2109 9.375 11V10.0625ZM6.375 10.0625H4.125V11.375H6.375V10.0625ZM3 10.0625H1.125V11C1.125 11.2109 1.28906 11.375 1.5 11.375H3V10.0625ZM6.375 5H4.125V6.3125H6.375V5Z" fill="#DF2E2E"/>
									</svg>
										15 January, 2025
								</span>
								<a href="#">Achieve Financial Excellence <br> with Proven Expertise</a>
							</div>
						</div>
					</div>
					<div class="si__blog__details__widget wow fadeInUp animated" data-wow-delay=".6s">
						<h6>Category</h6>
						<div class="si__blog__details__texttwo">
							<span> <a href="#">Profit Maximizers</a></span>
							<span><a href="#">Performance Boosters</a></span>
							<span><a href="#">Optimization Services</a></span>
							<span><a href="#">Cost Reduction Solutions</a></span>
							<span><a href="#">Business Loan Consultation</a></span>
							<span><a href="#">Forecasting Services</a></span>
						</div>
					</div>
					<div class="si__blog__details__widget wow fadeInUp animated" data-wow-delay=".9s">
						<h6>Category</h6>
						<div class="si__blog__details__textthree">
							<span><a href="#">Loan</a></span>
							<span><a href="#">Budgeting</a></span>
							<span><a href="#">Forecasting</a></span>
							<span><a href="#">Services</a></span>
							<span><a href="#">Financial</a></span>
							<span><a href="#">Boosters</a></span>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

@include('partials.footer')

@endsection