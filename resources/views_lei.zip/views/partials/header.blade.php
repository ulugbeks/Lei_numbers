<!-- pre loader area start -->
<div id="loading">
	<div id="loading-center">
	<div id="loading-center-absolute">
		<!-- loading content here -->
		<div class="preloader__content text-center">
			<div class="preloader__logo">
				<img src="{{ asset('assets/images/logo/logo__white.png') }}" alt="">
			</div>
			<div id="st-loading-bar" class="preloader__bar">
				<div id="st-loading-line" class="preloader__bar-inner"></div>
			</div>
		</div>
	</div>
	</div>  
</div>
<!-- pre loader area end -->

<!-- SI Header Area -->
<section id="header-sticky" class="si__header__area">
	<div class="container custom__container">
		<div class="row">
			<div class="col-lg-3">
				<div class="si__header__logo">
					<a href="index.html"><img src="assets/images/logo/logo.png" alt="logo"></a>
				</div>
			</div>
			<div class="col-lg-9">
				<div class="si__header__content">
					<div class="si__header__menubar">
						<div class="si__header__menu">
							<ul>
								<li class="current__item"><a href="/"> Home <i class="fa-light"></i> </a>
								</li>
								<li><a href="/about">About Us <i class="fa-light"></i> </a>
								</li>
								<li><a href="/blog">Blog <i class="fa-light"></i> </a>
								</li>
								<li><a href="/contact">Contact</a></li>
							</ul>
						</div>
					</div>
					<div class="si__header__right">
						<div class="search-box-btn search-box-outer"><i class="fa-sharp fa-solid fa-magnifying-glass"></i></div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<!-- Mobile Menu Area -->
<section class="si__mobilemenu__area">
	<div class="mobile-menu">
		<nav class="si_menu">
			<ul>
				<li class="current__item"><a href="/"> Home </a>
				</li>
				<li><a href="/about">About Us </a>
				</li>
				<li><a href="/blog">Blog </a>
				</li>
				<li><a href="/contact">Contact</a></li>
			</ul>
		</nav>
	</div>
</section>