<!-- SI Fotter Area -->
<section class="si__fotter__area bg" style="background: url(assets/images/fotter/Fotter.jpg);">
	<div class="container">
		<div class="row">
			<div class="col-lg-3 col-md-6 col-sm-6 wow fadeInUp animated" data-wow-delay=".3s">
				<div class="si__fotter__box">
					<div class="si__fotter__box__icon">
						<a href="index.html"> <img src="{{ asset('assets/images/logo/logo__white.png') }}" alt=""> </a>
						<p>It is a long established fact that a <br> reader will be distracted</p>
					</div>
					<div class="si__fotter__box__social">
						<a href="#"><i class="fa-brands fa-instagram"></i></a>
						<a href="#"><i class="fa-brands fa-facebook-f"></i></a>
						<a href="#"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d="M389.2 48h70.6L305.6 224.2 487 464H345L233.7 318.6 106.5 464H35.8L200.7 275.5 26.8 48H172.4L272.9 180.9 389.2 48zM364.4 421.8h39.1L151.1 88h-42L364.4 421.8z"/></svg></a>
						<a href="#"><i class="fa-brands fa-linkedin-in"></i></a>
					</div>
				</div>
			</div>
			<div class="col-lg-3 col-md-6 col-sm-6 wow fadeInUp animated" data-wow-delay=".6s">
				<div class="si__fotter__text">
					<h6>About Company</h6>
					<ul>
						<li><a href="#">Service</a></li>
						<li><a href="#">FAQ</a></li>
						<li><a href="#">Testimonial</a></li>
						<li><a href="#">About Us</a></li>
					</ul>
				</div>
			</div>
			<div class="col-lg-3 col-md-6 col-sm-6 wow fadeInUp animated" data-wow-delay=".9s">
				<div class="si__fotter__link">
					<h6>Our Office</h6>
					<a href="mailto:saadalam291@gmail.com"><i class="fa-light fa-envelope"></i> Saadalam291@gmail.com</a>
					<a href="#"><i class="fa-regular fa-location-dot"></i> 3891 Ranchview Dr. Richardson, <br> California 62639</a>
				</div>
			</div>
			<div class="col-lg-3 col-md-6 col-sm-6 wow fadeInUp animated" data-wow-delay="1.2s">
				<div class="si__fotter__content">
					<h6>Stay Connected</h6>
					<p>The generated is therefore always <br> free from repetition is</p>
					<div class="si__fotter__mailchimp__form">
						<form action="https://formspree.io/f/maygbqwa" method="post">
							<input name="email" type="email" placeholder="Your Email...">
							<button type="submit"> <i class="fa-sharp fa-light fa-paper-plane"></i> </button>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="si__fotter__copyright">
		<div class="container">
			<div class="row">
				<div class="col-lg-6">
					<div class="si__fotter__copyright__content">
						<p>© {{ date('Y') }} | All Rights Reserved</p>
					</div>
				</div>
				<div class="col-lg-6">
					<div class="si__fotter__copyright__text text-end">
						<ul>
							<li><a href="about-us.html"> Trams & Condition </a></li>
							<li><a href="about-us.html">Privacy Policy</a></li>
							<li><a href="about-us.html">Contact Us</a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<!-- Scrollup -->
<div id="scroll-percentage"><span id="scroll-percentage-value"></span></div>

<!--==================================================-->
<!-- Start Search Popup Area -->
<!--==================================================-->
<div class="search-popup">
	<button class="close-search style-two"><i class="fa-sharp fa-light fa-xmark"></i></button>
	<button class="close-search"><i class="fa-sharp fa-regular fa-up"></i></button>
	<form method="post" action="#">
		<div class="form-group">
			<input type="search" name="search-field" value="" placeholder="Search Here" required="">
			<button type="submit"><i class="fa-sharp fa-solid fa-magnifying-glass"></i></button>
		</div>
	</form>
</div>
<!--==================================================-->
<!-- End Search Popup Area -->
<!--==================================================-->